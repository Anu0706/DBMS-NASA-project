	<!-- ====================================================
	header section -->
	<header class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-xs-4 header-logo">
					<br>
					<a href="index.php" target="_blank"><img src="img/logo.png" alt="" class="img-responsive logo" style="width:120px;height:120px;"></a>
				</div>

				

					    <!-- Collect the nav links, forms, and other content for toggling -->
					    <div>
					      <style>
								.sandy a{
										float:left;
										display:block;
										padding:10px;
										font-size:20px;
										margin-top:3%;
								}
							</style>
					      <ul class="sandy">
					        <li><a  href="Scientist.php">Home</a></li>
					        <li><a  href="View Scientist.php">View Scientists</a></li>
					        <li><a href="View Mission.php">View Missions</a></li>
					        <li><a  href="View Visitors.php">View Visitors</a></li>
							<li><a  href="login.php">Message</a></li>
							<li><a  href="View Mission.php">View Missions</a></li>
					        <li><a  href="View Visitors.php">View Visitors</a></li>
							<li><a  href="login.php">Message</a></li>
					      </ul>
					    </div><!-- /navbar-collapse -->
					  </div><!-- / .container-fluid -->
					</nav>
				</div>
			</div>
		</div>
	</header> <!-- end of header area -->
<br/>
