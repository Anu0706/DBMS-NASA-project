	
	<!-- ====================================================
	header section -->
	<header class="top-header">
		<div class="container">			
			<div class="row">
				<div class="col-xs-4 header-logo"><br/>
					<a href="index.php" target="_blank"><img src="img/logo.png" alt="" class="img-responsive logo" style="width:120px;height:120px;"></a>
				</div>

				<div class="col-md-7">
					<nav class="navbar navbar-default">
					  <div class="container-fluid nav-bar">
					    <!-- Brand and toggle get grouped for better mobile display -->
					    
					    

					    <!-- Collect the nav links, forms, and other content for toggling -->
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					      
					      <ul class="nav navbar-nav navbar-right">
							<li><a class="menu" href="admin.php">Home</a></li>
					        <li><a class="menu" href="Scientist SignIn.php" >Add Admin/Scientist</a></li>
					        <li><a class="menu" href="Add Mission.php">Add Mission</a></li>
					        <li><a class="menu" href="Add Department.php">Add Department</a></li>
							<li><a class="menu" href="New Message.php">Compose Message</a></li>
							<li><a class="menu" href="HomePage.php">Log out</a></li>
					        <li><a class="menu" href="View Admin.php">View Admin</a></li>
							<li><a class="menu" href="View Scientist.php">View Scientists</a></li>
					        <li><a class="menu" href="View Mission.php">View Missions</a></li>
							<li><a class="menu" href="View Department.php">View Departments</a></li>
					        <li><a class="menu" href="View Visitors.php">View Visitors</a></li>
					      </ul>
					    </div><!-- /navbar-collapse -->
					  </div><!-- / .container-fluid -->
					</nav>
				</div>
			</div>
		</div>
	</header> <!-- end of header area -->