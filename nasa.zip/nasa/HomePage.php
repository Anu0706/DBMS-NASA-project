<!DOCTYPE html>
<html lang="en"> 
<head>
<?php
//Turn off
error_reporting(0);
  include "Head.php";
 ?>
</head>
<body>
	<br/>

		<div class="container">
			<div class="row">
				<div style="margin-top: 30px; background: #3a9dca;">
					<div class="contact-heading text-center">
						<h2>NASA DATABASE SYSTEM</h2>
						<font size="5" color="white">Exploring Other Worlds - Understanding Our Own</font>
						<center><img src="img/logo.png" style="width:250px;height:250px;">
					</div><br/>
					<table style="border-width:2px;">
				<tr>
					<th style="border-right:0px; background-color:#00283a;"><a href="AdminLogin.php" ><div class="contact-heading text-center"><h1>Admin Login</h1></div></a></th>
					<th style="border-right:0px; background-color:#00283a;"><a href="ScientistLogin.php"><div class="contact-heading text-center"><h1>Scientist Login</h1></div></a></th>
					<th style="border-right:0px; background-color:#00283a;"><a href="VisitorLogin.php"><div class="contact-heading text-center"><h1>Visitor Login</h1></div></a></th>
					<th style="border-right:0px; background-color:#00283a;"><a href="Visitors.php"><div class="contact-heading text-center"><h1>New Visitor</h1></div></a></th>
				</tr>	
				</table><br/><br/><br/>
</div>
			</div>
		</div>

</body>
</html>